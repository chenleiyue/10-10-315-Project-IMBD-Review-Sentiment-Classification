import numpy as np
import re

def extract_filename(x):
    l = []
    l = re.findall(r'\d+', x)
    return int(l[-1])

def match_result(tag_list_loc, result_list_loc):
    tag_list = np.load(tag_list_loc, allow_pickle=True)
    result_list = np.load(result_list_loc, allow_pickle=True)
    tag_list = np.array(list(map(extract_filename, tag_list)))
    assert(len(result_list) == len(tag_list))
    tuple_list = list((zip(tag_list, result_list)))
    dtype = [('tag', int), ('sentiment', int)]

    tuple_list = np.array(tuple_list, dtype=dtype)
    tuple_list = np.sort(tuple_list, order='tag') 
    result_list = list(map(lambda x: str(x[1]), tuple_list))
    
    return tuple_list, result_list

def write_result(result_list, testing=1):
    filename = 'testing1_result.txt'
    if(testing != 1):
        filename = 'testing2_result.txt'
    
    with open(filename, 'w+') as f:
        f.write('\n'.join(result_list))
        f.close()

def handling(tag_list_loc, result_list_loc, testing=1):
    tuple_list, result_list = match_result(tag_list_loc, result_list_loc)
    write_result(result_list, testing)

    
tag_loc = 'doc2vec_testing1_tag.npy'
res_loc = 'result_list1_300.npy'
handling(tag_loc, res_loc, 1)

tag_loc = 'doc2vec_testing2_tag.npy'
res_loc = 'result_list2_300.npy'
handling(tag_loc, res_loc, 2)
